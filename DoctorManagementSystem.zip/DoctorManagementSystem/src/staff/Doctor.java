package staff;

import patient.*;

public class Doctor extends User
{
	public Doctor(String name, String address, String phoneNo, String userID, String password) {
		super(name, address, phoneNo, userID, password);
		
	}
	
	public void checkSystem(String system, Examination E)
	{
		E.setSystem(system);
	}
	public void checkInspection(String inspection, Examination E)
	{
		E.setInspection(inspection);
	}
	public void checkPalpation(String palpation, Examination E)
	{
		E.setPalpation(palpation);
	}
	public void checkPercussion(String percussion, Examination E)
	{
		E.setPercussion(percussion);
	}
	public void checkAusculation(String ausculation, Examination E)
	{
		E.setAusculation(ausculation);
	}
	public void checkRelation(String relation, FamilyHistory F)
	{
		F.setRelation(relation);
	}
	public void checkDescription(String description, FamilyHistory F)
	{
		F.setRelation(description);
	}
	public void checkNote(String note, Instruction I)
	{
		I.setNote(note);
	}
	public void checkName(String name, Investigation I)
	{
		I.setName(name);
	}
	public void checkValue(float value, Investigation I)
	{
		I.setValue(value);
	}
	public void checkDisease(String disease, PastHistory P)
	{
		P.setDisease(disease);
	}
	public void checkDuration(String duration, PastHistory P)
	{
		P.setDuration(duration);
	}
	public void checkMedicine(String medicine, PastHistory P)
	{
		P.setMedicine(medicine);
	}
	public void checkDose(String dose, PastHistory P)
	{
		P.setDose(dose);
	}
	public void checkDoseFrequency(String doseFrequency, PastHistory P)
	{
		P.setDoseFrequency(doseFrequency);
	}
	public void checkName(String name, Patient P)
	{
		P.setName(name);
	}
	public void checkcaseType(String caseType, Patient P)
	{
		P.setcaseType(caseType);
	}
	public void checkHabit(String habit, PersonalHistory P)
	{
		P.setHabit(habit);
	}
	public void checkDuration(String duration, PersonalHistory P)
	{
		P.setDuration(duration);
	}
	public void checkDetail(String detail, PersonalHistory P)
	{
		P.setDetail(detail);
	}
	public void checkQuantity(String quantity, PersonalHistory P)
	{
		P.setQuantity(quantity);
	}
	public void checkDoctorName(String doctorName, Reference R)
	{
		R.setDoctorName(doctorName);
	}
	public void checkReferenceNotes(String referenceNotes, Reference R)
	{
		R.setReferenceNote(referenceNotes);
	}
	public void checkName(String name, RX R)
	{
		R.setName(name);
	}
	public void checkDrugForm(String drugForm, RX R)
	{
		R.setDrugForm(drugForm);
	}
	public void checkStrength(String strength, RX R)
	{
		R.setStrength(strength);
	}
	public void checkName(int quantity, RX R)
	{
		R.setQuantity(quantity);
	}
	public void checkDetail(String detail, RX R)
	{
		R.setDetail(detail);
	}
	public void checkDosage(String dosage, RX R)
	{
		R.setDosage(dosage);
	}
	public void checkDosageTime(String dosageTime, RX R)
	{
		R.setDosageTime(dosageTime);
	}
	public void checkBloodPressure(String bloodPressure, VitalData V)
	{
		V.setBloodPressure(bloodPressure);
	}
	public void checkPulse(int pulse, VitalData V)
	{
		V.setPulse(pulse);
	}
	public void checkspO2(int spO2, VitalData V)
	{
		V.setSpO2(spO2);
	}
	public void checkWeight(int weight, VitalData V)
	{
		V.setWeight(weight);
	}
	public void checkTemperature(float temperature, VitalData V)
	{
		V.setBodyTemperature(temperature);
	}
}
