package staff;

import java.sql.SQLException;
import dbconnection.AppointmentConnection;

public class Appointment {
	
	private String AppointmentID;
	private String appointmentTime;
	private String reason;
	private String PatientID;
	private String PatientName;
	
	public Appointment(String appointmentID, String appointmentTime, String reason, String patientID, String patientName) {
		AppointmentID = appointmentID;
		this.appointmentTime = appointmentTime;
		this.reason = reason;
		this.PatientID = patientID;
		this.PatientName = patientName;
	}
	
	
	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getPatientName() {
		return PatientName;
	}

	public void setPatientName(String patientName) {
		PatientName = patientName;
	}

	public String getAppointmentTime() 
	{
		return appointmentTime;
	}
	
	public void setAppointmentTime(String appointmentTime) 
	{
		this.appointmentTime = appointmentTime;
	}
	
	public String getReason() 
	{
		return reason;
	}
	
	public void setReason(String reason) 
	{
		this.reason = reason;
	}

	public String getAppointmentID() {
		return AppointmentID;
	}

	public void setAppointmentID(String appointmentID) {
		AppointmentID = appointmentID;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		AppointmentConnection Conn = new AppointmentConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		AppointmentConnection Conn = new AppointmentConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		AppointmentConnection Conn = new AppointmentConnection();
		Conn.delete(this);
	}

}
