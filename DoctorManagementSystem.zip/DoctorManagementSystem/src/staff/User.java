package staff;

public abstract class User {
	private String Name;
	private String Address;
	private String PhoneNo;
	private String UserID;
	private String Password;
	public User(String name, String address, String phoneNo, String userID, String password) {
		Name = name;
		Address = address;
		PhoneNo = phoneNo;
		UserID = userID;
		Password = password;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	public boolean login(String UserID,String Password)
	{
		if(this.UserID == UserID && this.Password == Password)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
