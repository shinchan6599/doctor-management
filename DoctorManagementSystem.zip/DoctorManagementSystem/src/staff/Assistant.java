package staff;
import patient.VitalData;

public class Assistant extends User
{
	public Assistant(String name, String address, String phoneNo, String userID, String password) {
		super(name, address, phoneNo, userID, password);
	}
	public void checkBP(String bp,VitalData V)
	{
		V.setBloodPressure(bp);
	}
	public void checkPulse(int pulse,VitalData V)
	{
		V.setPulse(pulse);
	}
	
}

