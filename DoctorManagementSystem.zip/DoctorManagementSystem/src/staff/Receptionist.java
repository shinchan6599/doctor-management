package staff;
public class Receptionist extends User
{
	public Receptionist(String name, String address, String phoneNo, String userID, String password) {
		super(name, address, phoneNo, userID, password);
	}
}
