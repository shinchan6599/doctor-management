package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class CloseController {
	@FXML
	private Label PatientID;
	@FXML
	private Label PatientName;
	@FXML
	private Label Symptoms;
	@FXML
	private Label ASymptoms;
	@FXML
	private Label Duration;
	@FXML
	private Label Description;
	
	public void Print(String patientID,String patientName,String symptoms,String AssociatedSymptoms,String duration,String description)
	{
		PatientID.setText(patientID);
		PatientName.setText(patientName);
		Symptoms.setText(symptoms);
		ASymptoms.setText(AssociatedSymptoms);
		Duration.setText(duration);
		Description.setText(description);
	}
}
