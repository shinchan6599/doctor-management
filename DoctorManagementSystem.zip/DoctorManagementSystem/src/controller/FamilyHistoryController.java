package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class FamilyHistoryController{
	@FXML
	private TextField AppointmentID;
	@FXML
	private TextField PatientID;
	@FXML
	private TextField PatientName;
	@FXML
	private Button Done;
	
	
	public void Done(ActionEvent E) throws Exception
	{
		((Node)E.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		System.out.println("7");
		Pane root = loader.load(getClass().getResource("/patientview/InvestigationView.fxml").openStream());
		System.out.println("7");
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	

}
