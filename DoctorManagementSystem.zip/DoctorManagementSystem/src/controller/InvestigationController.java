package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class InvestigationController {
	@FXML
	private TextField AppointmentID;
	@FXML
	private TextField PatientID;
	@FXML
	private TextField PatientName;
	@FXML
	private Button Close;
	
	public void Close(ActionEvent E) throws Exception
	{
		((Node)E.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		Pane root = loader.load(getClass().getResource("/patientview/CloseView.fxml").openStream());
		CloseController C = (CloseController)loader.getController();
		C.Print("1", "Dhyey", "Cold", "Viral Infection", "1 Week", "With little bit of dizyness");
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
}
