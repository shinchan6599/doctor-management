package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class PersonalHistoryController{
	
	@FXML
	private TextField AppointmentID;
	@FXML
	private TextField PatientID;
	@FXML
	private TextField PatientName;
	@FXML
	private Button Done;
	
	public void Start(String PatientId)
	{
		PatientID.setText(PatientId);
	}
	
	public void Done(ActionEvent E) throws Exception
	{
		((Node)E.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		System.out.println("5");
		Pane root = loader.load(getClass().getResource("/patientview/FamilyHistoryView.fxml").openStream());
		System.out.println("6");
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	

}
