package controller;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import dbconnection.ComplaintsConnection;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import patient.Complaints;
import patient.Patient;
import staff.Appointment;

public class ComplaintsController implements Initializable {
	
	@FXML
	private TextField AppointmentID;
	@FXML
	private TextField PatientID;
	@FXML
	private TextField PatientName;
	@FXML
	private TextField Symptoms;
	@FXML
	private TextField ASymptoms;
	@FXML
	private TextField Duration;
	@FXML
	private TextField Description;
	@FXML
	private TableView<Complaints> list;
	@FXML 
	private TableColumn<Complaints,String> CSymptoms;
	@FXML 
	private TableColumn<Complaints,String> CASymptoms;
	@FXML 
	private TableColumn<Complaints,String> CDuration;
	@FXML 
	private TableColumn<Complaints,String> CDescription;
	@FXML
	private Button Add;
	@FXML
	private Button Modify;
	@FXML
	private Button Delete;
	@FXML
	private Button Done;
	
	private static Integer complaintID = 10;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}
	
	public void Start(String AppointmentId,String PatientId,String Patientname)
	{
		AppointmentID.setText(AppointmentId);
		PatientID.setText(PatientId);
		PatientName.setText(Patientname);
	}
	
	public void Display(String PatientId)
	{
		try {
			ObservableList<Complaints> Data = ComplaintsConnection.view(PatientId);
			CSymptoms.setCellValueFactory(new PropertyValueFactory<Complaints,String>("Symptom"));
			CASymptoms.setCellValueFactory(new PropertyValueFactory<Complaints,String>("AssociatedSymptom"));
			CDuration.setCellValueFactory(new PropertyValueFactory<Complaints,String>("Duration"));
			CDescription.setCellValueFactory(new PropertyValueFactory<Complaints,String>("AdditionalDescription"));
			list.setItems(Data);
		} catch (Exception e) {
			e.printStackTrace();
		}		

	}
	
	public void Add(ActionEvent E) throws ClassNotFoundException, SQLException
	{
		String patientID = PatientID.getText();
		String symptom = Symptoms.getText();
		String AssociatedSymptom = ASymptoms.getText();
		String duration = Duration.getText();
		String AddDescription = Description.getText();
		complaintID++;
		
		Complaints C = new Complaints(AppointmentID.getText(), patientID, symptom, AssociatedSymptom, duration, AddDescription);
		C.add();
		Display(patientID);
		System.out.println("1234567890");
	}
	
	public void Delete(ActionEvent E) throws ClassNotFoundException, SQLException
	{
		ObservableList<Complaints> Selected;
		Selected = list.getSelectionModel().getSelectedItems();
		for(Complaints A : Selected)
		{
			A.delete();
		}
		Display(PatientID.getText());
	}
	
	public void Modify(ActionEvent E)
	{
		ObservableList<Complaints> Selected;
		Selected = list.getSelectionModel().getSelectedItems();
		for(Complaints A : Selected)
		{
			Symptoms.setText(A.getSymptom());
			ASymptoms.setText(A.getAssociatedSymptom());
			Duration.setText(A.getDuration());
			Description.setText(A.getAdditionalDescription());
		}
	}
	
	public void Done(ActionEvent E) throws Exception
	{
		((Node)E.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		System.out.println("3");
		Pane root = loader.load(getClass().getResource("/patientview/PersonalHistoryView.fxml").openStream());
		System.out.println("4");
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
}
