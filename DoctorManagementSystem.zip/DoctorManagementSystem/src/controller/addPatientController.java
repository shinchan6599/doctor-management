package controller;
import dbconnection.AppointmentConnection;
import java.net.URL;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import patient.Patient;
import staff.Appointment;

import java.util.ResourceBundle;

public class addPatientController implements Initializable {
	
	static Integer AppointmentID = 10;
	@FXML
	private TextField SearchName;
	@FXML
	private TextField SearchPhoneNo;
	@FXML
	private TextField PatientID;
	@FXML
	private Button Search;
	@FXML
	private TextField AddName;
	@FXML
	private TextField AddPhoneNo;
	@FXML
	private TextField CaseType;
	@FXML
	private TextField AppointmentTime;
	@FXML
	private TextField AppointmentReason;
	@FXML
	private Button Add;
	@FXML
	private Button Done;
	@FXML
	private TableView<Appointment> list;
	@FXML
	private TableColumn<Appointment,String> TAppointmentID;
	@FXML
	private TableColumn<Appointment,String> TPatientID;
	@FXML
	private TableColumn<Appointment,String> TPatientName;
	@FXML
	private TableColumn<Appointment,String> TTime;
	@FXML
	private TableColumn<Appointment,String> TReason;
	@FXML
	private Button Delete;
	@FXML
	private Button Modify;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			ObservableList<Appointment> Data = AppointmentConnection.view();
			TAppointmentID.setCellValueFactory(new PropertyValueFactory<Appointment,String>("AppointmentID"));
			TPatientID.setCellValueFactory(new PropertyValueFactory<Appointment,String>("PatientID"));
			TPatientName.setCellValueFactory(new PropertyValueFactory<Appointment,String>("PatientName"));
			TTime.setCellValueFactory(new PropertyValueFactory<Appointment,String>("appointmentTime"));
			TReason.setCellValueFactory(new PropertyValueFactory<Appointment,String>("reason"));
			list.setItems(Data);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public void Add(ActionEvent E) throws ClassNotFoundException, SQLException
	{
		String patientID = PatientID.getText();
		String addName = AddName.getText();
		String addPhoneNo = AddPhoneNo.getText();
		String caseType = CaseType.getText();
		AppointmentID++;
		if(caseType.equals("New"))
		{
			Patient P = new Patient(patientID, addName, caseType, addPhoneNo);
			P.add();
		}
		String appointmentTime = AppointmentTime.getText();
		String appointmentReason = AppointmentReason.getText();
		Appointment A = new Appointment(AppointmentID.toString(),appointmentTime, appointmentReason, patientID, addName);
		A.add();
		
		ResourceBundle resources = null;
		URL location = null;
		initialize(location, resources);
	}
	
	public void Delete(ActionEvent E) throws ClassNotFoundException, SQLException
	{
		ObservableList<Appointment> Selected;
		Selected = list.getSelectionModel().getSelectedItems();
		for(Appointment A : Selected)
		{
			A.delete();
		}
		ResourceBundle resources = null;
		URL location = null;
		initialize(location, resources);
	}
	
	public void Modify(ActionEvent E)
	{
		Appointment Selected;
		Selected = list.getSelectionModel().getSelectedItem();
		AddName.setText(Selected.getPatientName());
		PatientID.setText(Selected.getPatientID());
		AppointmentTime.setText(Selected.getAppointmentTime());
		AppointmentReason.setText(Selected.getReason());
		
	}
	

	public void Search(ActionEvent E) throws ClassNotFoundException, SQLException
	{
		String searchName = SearchName.getText();
		String searchPhoneNo = SearchPhoneNo.getText();
		Patient P = new Patient(null, searchName, null, searchPhoneNo);
		P = P.search();
		PatientID.setText(P.getPatientID());
		AddName.setText(P.getName());
		AddPhoneNo.setText(P.getphoneNo());
		CaseType.setText("Old");
	}

	public void Done(ActionEvent E) throws Exception
	{
		((Node)E.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		System.out.println("1");
		Pane root = loader.load(getClass().getResource("/patientview/ComplaintsView.fxml").openStream());
		System.out.println("2");
		ComplaintsController C = (ComplaintsController)loader.getController();
		C.Start(list.getSelectionModel().getSelectedItem().getAppointmentID(), list.getSelectionModel().getSelectedItem().getPatientID(), list.getSelectionModel().getSelectedItem().getPatientName());
		C.Display(list.getSelectionModel().getSelectedItem().getPatientID());
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
		
}