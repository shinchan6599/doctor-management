package patient;

import java.sql.SQLException;
import dbconnection.ComplaintsConnection;

public class Complaints {
	private String ComplaintID;
	private String PatientID;
	private String Symptom;
	private String AssociatedSymptom;
	private String Duration;
	private String AdditionalDescription;
	public Complaints(String complaintID, String patientID, String symptom, String associatedSymptom, String duration,
			String additionalDescription) {
		ComplaintID = complaintID;
		PatientID = patientID;
		Symptom = symptom;
		AssociatedSymptom = associatedSymptom;
		Duration = duration;
		AdditionalDescription = additionalDescription;
	}
	
	public String getComplaintID() {
		return ComplaintID;
	}

	public void setComplaintID(String complaintID) {
		ComplaintID = complaintID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getSymptom() {
		return Symptom;
	}
	public void setSymptom(String symptom) {
		Symptom = symptom;
	}
	public String getAssociatedSymptom() {
		return AssociatedSymptom;
	}
	public void setAssociatedSymptom(String associatedSymptom) {
		AssociatedSymptom = associatedSymptom;
	}
	public String getDuration() {
		return Duration;
	}
	public void setDuration(String duration) {
		Duration = duration;
	}
	public String getAdditionalDescription() {
		return AdditionalDescription;
	}
	public void setAdditionalDescription(String additionalDescription) {
		AdditionalDescription = additionalDescription;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		ComplaintsConnection Conn = new ComplaintsConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		ComplaintsConnection Conn = new ComplaintsConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		ComplaintsConnection Conn = new ComplaintsConnection();
		Conn.delete(this);
	}
}
