package patient;

import java.sql.SQLException;
import dbconnection.ExaminationConnection;

public class Examination {
	private String ExaminationID;
	private String PatientID;
	private String system;
	private String Inspection;
	private String Palpation;
	private String Percussion;
	private String Ausculation;
	
		
	public Examination(String examinationID, String patientID, String system, String inspection, String palpation,
			String percussion, String ausculation) {
		super();
		ExaminationID = examinationID;
		PatientID = patientID;
		this.system = system;
		Inspection = inspection;
		Palpation = palpation;
		Percussion = percussion;
		Ausculation = ausculation;
	}
	
	public String getExaminationID() {
		return ExaminationID;
	}

	public void setExaminationID(String examinationID) {
		ExaminationID = examinationID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getSystem() {
		return system;
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getInspection() {
		return Inspection;
	}
	public void setInspection(String inspection) {
		Inspection = inspection;
	}
	public String getPalpation() {
		return Palpation;
	}
	public void setPalpation(String palpation) {
		Palpation = palpation;
	}
	public String getPercussion() {
		return Percussion;
	}
	public void setPercussion(String percussion) {
		Percussion = percussion;
	}
	public String getAusculation() {
		return Ausculation;
	}
	public void setAusculation(String ausculation) {
		Ausculation = ausculation;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		ExaminationConnection Conn = new ExaminationConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		ExaminationConnection Conn = new ExaminationConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		ExaminationConnection Conn = new ExaminationConnection();
		Conn.delete(this);
	}
	
}
