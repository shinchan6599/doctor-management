package patient;

public class Report {
	private String PatientID;

	public Report(String patientID) {
		PatientID = patientID;
	}
}
