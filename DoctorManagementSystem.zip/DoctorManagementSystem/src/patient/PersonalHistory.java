package patient;

import java.sql.SQLException;

import dbconnection.PastHistoryConnection;
import dbconnection.PersonalHistoryConnection;

public class PersonalHistory {
	
	private String PersonalHistoryID;
	private String PatientID;
	private String Habit;
	private String Duration;
	private String Detail;
	private String Quantity;
	
	public PersonalHistory(String personalhistoryId,String patientID,String habit, String duration, String detail, String quantity) {
		PatientID = patientID;
		PersonalHistoryID = personalhistoryId;
		Habit = habit;
		Duration = duration;
		Detail = detail;
		Quantity = quantity;
	}

	public String getPersonalHistoryID() {
		return PersonalHistoryID;
	}

	public void setPersonalHistoryID(String personalHistoryID) {
		PersonalHistoryID = personalHistoryID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getHabit() {
		return Habit;
	}

	public void setHabit(String habit) {
		Habit = habit;
	}

	public String getDuration() {
		return Duration;
	}

	public void setDuration(String duration) {
		Duration = duration;
	}

	public String getDetail() {
		return Detail;
	}

	public void setDetail(String detail) {
		Detail = detail;
	}

	public String getQuantity() {
		return Quantity;
	}

	public void setQuantity(String quantity) {
		Quantity = quantity;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		PersonalHistoryConnection Conn = new PersonalHistoryConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		PersonalHistoryConnection Conn = new PersonalHistoryConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		PersonalHistoryConnection Conn = new PersonalHistoryConnection();
		Conn.delete(this);
	}


}
