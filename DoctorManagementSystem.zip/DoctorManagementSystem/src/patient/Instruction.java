package patient;

import java.sql.SQLException;
import dbconnection.InstructionConnection;

public class Instruction {
	private String InstructionID;
	private String PatientID;
	private String Note;

	public Instruction(String instructionID, String patientID, String note) {
		super();
		InstructionID = instructionID;
		PatientID = patientID;
		Note = note;
	}

	public String getInstructionID() {
		return InstructionID;
	}

	public void setInstructionID(String instructionID) {
		InstructionID = instructionID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getNote() {
		return Note;
	}

	public void setNote(String note) {
		Note = note;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		InstructionConnection Conn = new InstructionConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		InstructionConnection Conn = new InstructionConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		InstructionConnection Conn = new InstructionConnection();
		Conn.delete(this);
	}
	
}
