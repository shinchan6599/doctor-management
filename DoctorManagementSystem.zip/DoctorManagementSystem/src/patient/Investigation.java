package patient;

import java.sql.SQLException;
import dbconnection.InvestigationConnection;

public class Investigation {
	private String InvestigationID;
	private String PatientID;
	private String Name;
	private float Value;
	
	public Investigation(String investigationID, String patientID, String name, float value) {
		super();
		InvestigationID = investigationID;
		PatientID = patientID;
		Name = name;
		Value = value;
	}
	
	public String getInvestigationID() {
		return InvestigationID;
	}

	public void setInvestigationID(String investigationID) {
		InvestigationID = investigationID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public float getValue() {
		return Value;
	}
	public void setValue(float value) {
		Value = value;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		InvestigationConnection Conn = new InvestigationConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		InvestigationConnection Conn = new InvestigationConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		InvestigationConnection Conn = new InvestigationConnection();
		Conn.delete(this);
	}

}
