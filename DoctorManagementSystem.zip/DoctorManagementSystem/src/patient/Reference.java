package patient;

import java.sql.SQLException;
import dbconnection.ReferenceConnection;

public class Reference {
	
	private String ReferenceID;
	private String PatientID;
	private String DoctorName;
	private String ReferenceNote;

	public String getPatientID() {
		return PatientID;
	}
	public void setPatientID(String patientID) {
		PatientID = patientID;
	}
	public String getReferenceID() {
		return ReferenceID;
	}
	public void setReferenceID(String referenceID) {
		ReferenceID = referenceID;
	}
	public Reference(String referenceID, String patientID, String doctorName, String referenceNote) {
		super();
		ReferenceID = referenceID;
		PatientID = patientID;
		DoctorName = doctorName;
		ReferenceNote = referenceNote;
	}
	public String getDoctorName() {
		return DoctorName;
	}
	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}
	public String getReferenceNote() {
		return ReferenceNote;
	}
	public void setReferenceNote(String referenceNote) {
		ReferenceNote = referenceNote;
	}
	public void add() throws ClassNotFoundException, SQLException
	{
		ReferenceConnection Conn = new ReferenceConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		ReferenceConnection Conn = new ReferenceConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		ReferenceConnection Conn = new ReferenceConnection();
		Conn.delete(this);
	}

}
