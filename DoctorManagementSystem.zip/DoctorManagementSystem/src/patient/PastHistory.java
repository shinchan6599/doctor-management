package patient;

import java.sql.SQLException;
import dbconnection.PastHistoryConnection;

public class PastHistory {
	
	private String PasthistoryID;
	private String PatientID;
	private String Disease;
	private String Duration;
	private String Medicine;
	private String Dose;
	private String DoseFrequency;
	
	

	public String getPasthistoryID() {
		return PasthistoryID;
	}

	public void setPasthistoryID(String pasthistoryID) {
		PasthistoryID = pasthistoryID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public PastHistory(String pasthistoryID, String patientID, String disease, String duration, String medicine,
			String dose, String doseFrequency) {
		super();
		PasthistoryID = pasthistoryID;
		PatientID = patientID;
		Disease = disease;
		Duration = duration;
		Medicine = medicine;
		Dose = dose;
		DoseFrequency = doseFrequency;
	}

	public String getDisease() {
		return Disease;
	}

	public void setDisease(String disease) {
		Disease = disease;
	}

	public String getDuration() {
		return Duration;
	}

	public void setDuration(String duration) {
		Duration = duration;
	}

	public String getMedicine() {
		return Medicine;
	}

	public void setMedicine(String medicine) {
		Medicine = medicine;
	}

	public String getDose() {
		return Dose;
	}

	public void setDose(String dose) {
		Dose = dose;
	}

	public String getDoseFrequency() {
		return DoseFrequency;
	}

	public void setDoseFrequency(String doseFrequency) {
		DoseFrequency = doseFrequency;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		PastHistoryConnection Conn = new PastHistoryConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		PastHistoryConnection Conn = new PastHistoryConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		PastHistoryConnection Conn = new PastHistoryConnection();
		Conn.delete(this);
	}

}
