package patient;

import java.sql.SQLException;
import dbconnection.VitalDataConnection;

public class VitalData {
	
	private String VitalDataID;
	private String PatientID;
	private String BloodPressure;
	private int Pulse;
	private int spO2;
	private int Weight;
	private float BodyTemperature;
	
	public VitalData(String Vitaldataid, String patientID,String bloodPressure, int pulse, int spO2, int weight, float bodyTemperature) {
		PatientID = patientID;
		VitalDataID = Vitaldataid;
		BloodPressure = bloodPressure;
		Pulse = pulse;
		this.spO2 = spO2;
		Weight = weight;
		BodyTemperature = bodyTemperature;
	}

	public String getVitalDataID() {
		return VitalDataID;
	}

	public void setVitalDataID(String vitalDataID) {
		VitalDataID = vitalDataID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getBloodPressure() {
		return BloodPressure;
	}

	public void setBloodPressure(String bloodPressure) {
		BloodPressure = bloodPressure;
	}

	public int getPulse() {
		return Pulse;
	}

	public void setPulse(int pulse) {
		Pulse = pulse;
	}

	public int getSpO2() {
		return spO2;
	}

	public void setSpO2(int spO2) {
		this.spO2 = spO2;
	}

	public int getWeight() {
		return Weight;
	}

	public void setWeight(int weight) {
		Weight = weight;
	}

	public float getBodyTemperature() {
		return BodyTemperature;
	}

	public void setBodyTemperature(float bodyTemperature) {
		BodyTemperature = bodyTemperature;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		VitalDataConnection Conn = new VitalDataConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		VitalDataConnection Conn = new VitalDataConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		VitalDataConnection Conn = new VitalDataConnection();
		Conn.delete(this);
	}
}
