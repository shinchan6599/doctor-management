package patient;

import java.sql.SQLException;
import dbconnection.PatientConnection;

public class Patient {
	private String PatientID;
	private String Name;
	private String caseType;
	private String phoneNo;
	
	public Patient(String patientID, String name, String caseType, String phoneNo) {
		PatientID = patientID;
		Name = name;
		this.caseType = caseType;
		this.phoneNo = phoneNo;
	}
	
	public String getcaseType() {
		return caseType;
	}

	public void setcaseType(String caseType) {
		this.caseType = caseType;
	}
	
	public String getPatientID() {
		return PatientID;
	}
	public void setPatientID(String patientID) {
		PatientID = patientID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	public String getphoneNo() {
		return phoneNo;
	}
	public void setphoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		PatientConnection Conn = new PatientConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		PatientConnection Conn = new PatientConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		PatientConnection Conn = new PatientConnection();
		Conn.delete(this);
	}
	
	public Patient search() throws ClassNotFoundException,SQLException
	{
		Patient P = null;
		PatientConnection Conn = new PatientConnection();
		P = Conn.search(this);
		return P;
	}

	
}
