package patient;

import java.sql.SQLException;
import dbconnection.RXConnection;

public class RX {
	private String RXID;
	private String PatientID;
	private String Name;
	private String DrugForm;
	private String Strength;
	private int Quantity;
	private String Detail;
	private String Dosage;
	private String DosageTime;
	
	
	public String getDosageTime() {
		return DosageTime;
	}

	public void setDosageTime(String dosageTime) {
		DosageTime = dosageTime;
	}

	public RX(String rXID, String patientID, String name, String drugForm, String strength, int quantity, String detail,
			String dosage, String dosageTime) {
		RXID = rXID;
		PatientID = patientID;
		Name = name;
		DrugForm = drugForm;
		Strength = strength;
		Quantity = quantity;
		Detail = detail;
		Dosage = dosage;
		DosageTime = dosageTime;
	}

	public String getRXID() {
		return RXID;
	}

	public void setRXID(String rXID) {
		RXID = rXID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getDrugForm() {
		return DrugForm;
	}
	public void setDrugForm(String drugForm) {
		DrugForm = drugForm;
	}
	public String getStrength() {
		return Strength;
	}
	public void setStrength(String strength) {
		Strength = strength;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public String getDetail() {
		return Detail;
	}
	public void setDetail(String detail) {
		Detail = detail;
	}
	public String getDosage() {
		return Dosage;
	}
	public void setDosage(String dosage) {
		Dosage = dosage;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		RXConnection Conn = new RXConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		RXConnection Conn = new RXConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		RXConnection Conn = new RXConnection();
		Conn.delete(this);
	}
	
}
