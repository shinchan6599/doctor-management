package patient;

import java.sql.SQLException;
import java.util.ArrayList;

import dbconnection.FamilyHistoryConnection;

public class FamilyHistory {
	private String FamilyHistoryID;
	private String PatientID;
	private String Relation;
	private String Description;

	public FamilyHistory(String patientID,String relation, String description, String familyHistoryID) {
		PatientID = patientID;
		Relation = relation;
		Description = description;
		FamilyHistoryID = familyHistoryID;
	}
	
	public String getFamilyHistoryID() {
		return FamilyHistoryID;
	}

	public void setFamilyHistoryID(String familyHistoryID) {
		FamilyHistoryID = familyHistoryID;
	}

	public String getPatientID() {
		return PatientID;
	}

	public void setPatientID(String patientID) {
		PatientID = patientID;
	}

	public String getRelation() {
		return Relation;
	}

	public void setRelation(String relation) {
		Relation = relation;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}
	
	public void add() throws ClassNotFoundException, SQLException
	{
		FamilyHistoryConnection Conn = new FamilyHistoryConnection();
		Conn.add(this);
	}
	
	public void update() throws ClassNotFoundException, SQLException
	{
		FamilyHistoryConnection Conn = new FamilyHistoryConnection();
		Conn.update(this);
	}
	
	public void delete() throws ClassNotFoundException, SQLException
	{
		FamilyHistoryConnection Conn = new FamilyHistoryConnection();
		Conn.delete(this);
	}
	
	
}
