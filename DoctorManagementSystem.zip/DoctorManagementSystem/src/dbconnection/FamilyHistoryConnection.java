package dbconnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mysql.jdbc.DatabaseMetaData;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.PreparedStatement;

import patient.FamilyHistory;

public class FamilyHistoryConnection {

	private static Connection conn = null;
	
	public FamilyHistoryConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	
	
	public void add (FamilyHistory currF) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "INSERT INTO `doctormangementsystem`.`familyhistory` (`FamilyHistoryID`, `PatientID`, `Relation`, `Description`) VALUES ('";
			sql += currF.getFamilyHistoryID() + "', '"; 
			sql += currF.getPatientID() + "', '";
			sql += currF.getRelation() + "', '";
			sql += currF.getDescription() + "')" ;
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}

	}
	
	public void update (FamilyHistory currF) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "UPDATE `doctormangementsystem`.`familyhistory` SET `PatientID`='";
			sql += currF.getPatientID() + "', `Relation`='"; 
			sql += currF.getRelation() + "', `Description`='";
			sql += currF.getDescription() + "' WHERE `FamilyHistoryID`='";
			sql += currF.getFamilyHistoryID() + "'" ;
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	
	
	public void delete (FamilyHistory currF) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "DELETE FROM `doctormangementsystem`.`familyhistory` WHERE `FamilyHistoryID`='";
			//sql += currF.getFamilyHistoryID() + "'" ;
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	public static ObservableList<FamilyHistory> view(FamilyHistory currF) throws  SQLException, Exception{
		   String sql=null;
		   sql = "SELECT * FROM `doctormangementsystem`.`familyhistory` WHERE `PatientID`=?";
		   PreparedStatement statement = conn.prepareStatement(sql);
		   statement.setString(1, currF.getPatientID());
		   
		   ResultSet Records = statement.executeQuery();
		   ObservableList<FamilyHistory> values = FXCollections.observableArrayList();
		   
		   while(Records.next()){
			   String FamilyHistoryId = Records.getString("FamilyHistoryID");
			   String PatientID = Records.getString("PatientID");
			   String Relation = Records.getString("Relation");
			   String Description = Records.getString("Description");
			   
			   values.add(new FamilyHistory(PatientID, Relation, Description, FamilyHistoryId));
		   }	   
		   return values;
	}
}
