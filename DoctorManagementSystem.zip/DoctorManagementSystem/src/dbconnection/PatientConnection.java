
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import patient.Patient;

public class PatientConnection {

	private Connection conn = null;
	
	public PatientConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (Patient currP) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`patient` (`PatientID`, `Name`, `caseType`, `phoneNo`) VALUES (?, ?, ?, ?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currP.getPatientID());
		statement.setString(2, currP.getName());
		statement.setString(3, currP.getcaseType());
		statement.setString(4, currP.getphoneNo());
		statement.execute();
	}
	
	public void update (Patient currP) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`patient` SET `Name`=?, `caseType`=?, `phoneNo`=? WHERE `PatientID`=?;";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(4, currP.getPatientID());
		statement.setString(1, currP.getName());
		statement.setString(2, currP.getcaseType());
		statement.setString(3, currP.getphoneNo());
		statement.execute();
	}
	
	
	
	public void delete (Patient currP) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`patient` WHERE `PatientID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currP.getPatientID());
		statement.execute();
	}
	
	public Patient search (Patient currP) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "SELECT * FROM doctormangementsystem.patient WHERE `Name`=? AND  `phoneNo`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currP.getName());
		statement.setString(2, currP.getphoneNo());
		ResultSet Records = statement.executeQuery();
	
		Records.next();
		String PatientId = Records.getString("PatientID");
		String Name = Records.getString("Name");
		String caseType = Records.getString("caseType");
		String phoneNo = Records.getString("phoneNo");
		Patient P = new Patient(PatientId, Name, caseType, phoneNo);
		return P;
	}
}
