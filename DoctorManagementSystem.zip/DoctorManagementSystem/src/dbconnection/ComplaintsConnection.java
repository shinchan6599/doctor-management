package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import patient.Complaints;

public class ComplaintsConnection {

	private static Connection conn = null;
	
	public ComplaintsConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (Complaints currC) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "INSERT INTO `doctormangementsystem`.`complaints` (`AppointmentID`, `PatientID`, `Symptom`, `AssociatedSymptom`, `Duration`, `AdditionalDesription`) VALUES ('";
			sql += currC.getComplaintID() + "', '"; 
			sql += currC.getPatientID() + "', '";
			sql += currC.getSymptom() + "', '";
			sql += currC.getAssociatedSymptom() + "', '";
			sql += currC.getDuration() + "', '";
			sql += currC.getAdditionalDescription() + "')" ;
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}

	}
	
	public void update (Complaints currC) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "UPDATE `doctormangementsystem`.`complaints` SET `PatientID`='";
			sql += currC.getPatientID() + "', `Symptom`='"; 
			sql += currC.getSymptom() + "', `AssociatedSymptom`='";
			sql += currC.getAssociatedSymptom() + "', `Duration`='";
			sql += currC.getDuration() + "', `AdditionalDesription`='";
			sql += currC.getAdditionalDescription() + "' WHERE `ComplaintID`='";
			sql += currC.getComplaintID() + "'";
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	
	
	public void delete (Complaints currC) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "DELETE FROM `doctormangementsystem`.`complaints` WHERE `ComplaintID`='";
			sql += currC.getComplaintID() + "'" ;
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	public static ObservableList<Complaints> view(String patientId) throws  SQLException, Exception{
		   String sql=null;
		   conn = DBSchemaConnection.getConnection();
		   sql = "SELECT * FROM `doctormangementsystem`.`complaints` WHERE `PatientID`=?";
		   PreparedStatement statement = conn.prepareStatement(sql);
		   statement.setString(1, patientId);
		   ResultSet Records = statement.executeQuery();
		   ObservableList<Complaints> values = FXCollections.observableArrayList();
		   while(Records.next()){
			   String ComplaintId = Records.getString("AppointmentID");
			   String PatientID = Records.getString("PatientID");
			   String Symptom = Records.getString("Symptom");
			   String AssociatedSymptom = Records.getString("AssociatedSymptom");
			   String Duration = Records.getString("Duration");
			   String AddDescription = Records.getString("AdditionalDesription");
			   values.add(new Complaints(ComplaintId, PatientID, Symptom, AssociatedSymptom, Duration, AddDescription));
		   }	   
		   return values;
	}

}
