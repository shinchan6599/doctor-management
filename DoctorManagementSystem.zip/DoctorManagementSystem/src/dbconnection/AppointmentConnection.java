
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import staff.Appointment;

public class AppointmentConnection {

	private static Connection conn = null;
	
	public void add (Appointment currA) throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`appointment` (`AppointmentID`,`appointmentTime`, `reason`, `PatientID`, `PatientName`) VALUES (?,?,?,?,?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currA.getAppointmentID());
		statement.setString(2, currA.getAppointmentTime());
		statement.setString(3, currA.getReason());
		statement.setString(4, currA.getPatientID());
		statement.setString(5, currA.getPatientName());
		statement.execute();
	}
	
	public void update (Appointment currA) throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`appointment` SET `appointmentDate`=?,`appointmentTime`=?, `reason`=? WHERE `AppointmentID`=?";

		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1,currA.getAppointmentTime());
		statement.setString(2, currA.getReason());
		statement.setString(3, currA.getPatientID());
		statement.setString(4, currA.getPatientName());
		statement.setString(5, currA.getAppointmentID());
		statement.execute();
	}
	
	
	
	public void delete (Appointment currA) throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`appointment` WHERE `AppointmentID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currA.getAppointmentID());
		statement.execute();
	}
	
	public static ObservableList<Appointment> view() throws  SQLException, Exception{
			conn = DBSchemaConnection.getConnection();
			Statement stmt = null;
			stmt = conn.createStatement();
			String sql=null;
			sql = "SELECT * FROM doctormangementsystem.appointment";
			ResultSet Records = stmt.executeQuery(sql);
			ObservableList<Appointment> values = FXCollections.observableArrayList();
		   while(Records.next()){
			   String AppointmentID = Records.getString("AppointmentID");
			   String Time = Records.getString("appointmentTime");
			   String Reason = Records.getString("reason");
			   String PatientID = Records.getString("PatientID");
			   String Name = Records.getString("PatientName");
			   Appointment A = new Appointment(AppointmentID, Time, Reason, PatientID, Name);
			   values.add(A);
		   }
		   return values;
	}

}

