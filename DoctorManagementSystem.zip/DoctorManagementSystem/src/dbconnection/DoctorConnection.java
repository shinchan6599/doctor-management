
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import staff.Doctor;

public class DoctorConnection {

	private Connection conn = null;
	
	public DoctorConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (Doctor currD) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`doctor` (`DoctorID`, `Name`, `Address`, `PhoneNo`) VALUES (?,?,?,?);";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currD.getUserID());
		statement.setString(2, currD.getName());
		statement.setString(3, currD.getAddress());
		statement.setString(4, currD.getPhoneNo());
		statement.execute();
	}
	
	public void update (Doctor currD) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`doctor` SET `Name`=?, `Address`=?, `PhoneNo`=? WHERE `DoctorID`=?";

		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1,currD.getName());
		statement.setString(2,currD.getAddress());
		statement.setString(3, currD.getPhoneNo());
		statement.setString(4, currD.getUserID());
		statement.execute();
	}
	
	
	
	public void delete (Doctor currD) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`doctor` WHERE `DoctorID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currD.getUserID());
		statement.execute();
	}

}

