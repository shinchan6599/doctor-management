
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import patient.Reference;

public class ReferenceConnection {

	private Connection conn = null;
	
	public ReferenceConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (Reference currR) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`reference` (`ReferenceID`, `PatientID`, `DoctorName`, `ReferenceNote`) VALUES (?,?,?,?);";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currR.getReferenceID());
		statement.setString(2, currR.getPatientID());
		statement.setString(3, currR.getDoctorName());
		statement.setString(4, currR.getReferenceNote());
		
		statement.execute();
	}
	
	public void update (Reference currR) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`reference` SET `PatientID`=?, `DoctorName`=?, `ReferenceNote`=? WHERE `ReferenceID`=?;";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(4, currR.getReferenceID());
		statement.setString(1, currR.getPatientID());
		statement.setString(2, currR.getDoctorName());
		statement.setString(3, currR.getReferenceNote());
		
		statement.execute();
	}
	
	
	
	public void delete (Reference currR) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`reference` WHERE `ReferenceID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currR.getReferenceID());
		statement.execute();
	}

}
