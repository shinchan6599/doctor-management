
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import patient.Instruction;

public class InstructionConnection {

	private Connection conn = null;
	
	public InstructionConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (Instruction currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`instruction` (`InstructionID`, `PatientID`, `Note`) VALUES (?, ?, ?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getInstructionID());
		statement.setString(2, currI.getPatientID());
		statement.setString(3, currI.getNote());
		statement.execute();
	}
	
	public void update (Instruction currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`instruction` SET `PatientID`=?, `Note`=? WHERE `InstructionID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getPatientID());
		statement.setString(2, currI.getNote());
		statement.setString(3, currI.getInstructionID());
		statement.execute();
	}
	
	
	
	public void delete (Instruction currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`instruction` WHERE `InstructionID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getInstructionID());
		statement.execute();
	}

}
