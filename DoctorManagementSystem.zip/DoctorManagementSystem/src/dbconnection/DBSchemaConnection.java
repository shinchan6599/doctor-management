package dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBSchemaConnection {

	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		
		
		   final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		   final String DB_URL = "jdbc:mysql://localhost/doctormangementsystem";

		   // UserName and Pass
		   final String USER = "Shinchan";
		   final String PASS = "dhyey@141";

		   Connection conn = null;
		   
		   Class.forName(JDBC_DRIVER);
		   
		   conn = DriverManager.getConnection(DB_URL,USER, PASS);
		   
		   return conn;
	}	
}
