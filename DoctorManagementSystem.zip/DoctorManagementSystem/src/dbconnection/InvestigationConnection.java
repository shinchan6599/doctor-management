
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import patient.Investigation;

public class InvestigationConnection {

	private Connection conn = null;
	
	public InvestigationConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (Investigation currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`investigation` (`InvestigationID`, `PatientID`, `Name`, `Value`) VALUES (?,?,?,?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getInvestigationID());
		statement.setString(2, currI.getPatientID());
		statement.setString(3, currI.getName());
		statement.setFloat(4, currI.getValue());
		statement.execute();
	}
	
	public void update (Investigation currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`investigation` SET `PatientID`=?, `Name`=?, `Value`=? WHERE `InvestigationID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getPatientID());
		statement.setString(2, currI.getName());
		statement.setFloat(3, currI.getValue());
		statement.setString(4, currI.getInvestigationID());
		statement.execute();
	}
	
	
	
	public void delete (Investigation currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`investigation` WHERE `InvestigationID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getInvestigationID());
		statement.execute();
	}

}
