
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import patient.PastHistory;

public class PastHistoryConnection {

	private Connection conn = null;
	
	public PastHistoryConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (PastHistory currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`pasthistory` (`PasthistoryID`, `PatientID`, `Disease`, `Duration`, `Medicine`, `Dose`, `DoseFrequency`) VALUES (?,?,?,?,?,?,?);";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getPasthistoryID());
		statement.setString(2, currI.getPatientID());
		statement.setString(3, currI.getDisease());
		statement.setString(4, currI.getDuration());
		statement.setString(5, currI.getMedicine());
		statement.setString(6, currI.getDose());
		statement.setString(7, currI.getDoseFrequency());
		statement.execute();
	}
	
	public void update (PastHistory currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`pasthistory` SET `PatientID`=?, `Disease`=?, `Duration`=?,`Medicine`=?,`Dose`=?,`DoseFrequency`=? WHERE `PasthistoryID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getPatientID());
		statement.setString(2, currI.getDisease());
		statement.setString(3, currI.getDuration());
		statement.setString(4, currI.getMedicine());
		statement.setString(5, currI.getDose());
		statement.setString(6, currI.getDoseFrequency());
		statement.setString(7, currI.getPasthistoryID());
		statement.execute();
	}
	
	
	
	public void delete (PastHistory currI) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`pasthistory` WHERE `PasthistoryID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currI.getPasthistoryID());
		statement.execute();
	}

}
