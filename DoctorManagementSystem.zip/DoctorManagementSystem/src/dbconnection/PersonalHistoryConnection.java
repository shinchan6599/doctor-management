
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import patient.PersonalHistory;

public class PersonalHistoryConnection {

	private Connection conn = null;
	
	public PersonalHistoryConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (PersonalHistory currP) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`personalhistory` (`PersonalHistoryID`, `PatientID`, `Habit`, `Duration`, `Detail`, `Quantity`) VALUES (?,?,?,?,?,?);";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currP.getPersonalHistoryID());
		statement.setString(2, currP.getPatientID());
		statement.setString(3, currP.getHabit());
		statement.setString(4, currP.getDuration());
		statement.setString(5, currP.getDetail());
		statement.setString(6, currP.getQuantity());
		statement.execute();
	}
	
	public void update (PersonalHistory currP) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`personalhistory` SET `PatientID`=?, `Habit`=?, `Duration`=?, `Detail`=?, `Quantity`=? WHERE `PersonalHistoryID`=?;";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(6, currP.getPersonalHistoryID());
		statement.setString(1, currP.getPatientID());
		statement.setString(2, currP.getHabit());
		statement.setString(3, currP.getDuration());
		statement.setString(4, currP.getDetail());
		statement.setString(5, currP.getQuantity());
		statement.execute();
	}
	
	
	
	public void delete (PersonalHistory currP) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`personalhistory` WHERE `PersonalHistoryID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currP.getPersonalHistoryID());
		statement.execute();
	}

}
