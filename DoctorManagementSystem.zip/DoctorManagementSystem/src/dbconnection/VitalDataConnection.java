
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import patient.VitalData;

public class VitalDataConnection {

	private Connection conn = null;
	
	public VitalDataConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (VitalData currV) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`vitaldata` (`VitalDataID`, `PatientID`, `BloodPressure`, `Pulse`, `spO2`, `Weight`, `BodyTemperature`) VALUES (?,?,?,?,?,?,?);";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currV.getVitalDataID());
		statement.setString(2, currV.getPatientID());
		statement.setString(3, currV.getBloodPressure());
		statement.setInt(4, currV.getPulse());
		statement.setInt(5, currV.getSpO2());
		statement.setInt(6, currV.getWeight());
		statement.setFloat(7, currV.getBodyTemperature());
		statement.execute();
	}
	
	public void update (VitalData currV) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`vitaldata` SET `PatientID`=?, `BloodPressure`=?, `Pulse`=?, `spO2`=?, `Weight`=?, `BodyTemperature`=? WHERE `VitalDataID`=?;";

		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currV.getPatientID());
		statement.setString(2, currV.getBloodPressure());
		statement.setInt(3, currV.getPulse());
		statement.setInt(4, currV.getSpO2());
		statement.setInt(5, currV.getWeight());
		statement.setFloat(6, currV.getBodyTemperature());
		statement.setString(7, currV.getVitalDataID());
		statement.execute();
	}
	
	
	
	public void delete (VitalData currV) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`vitaldata` WHERE `VitalDataID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currV.getVitalDataID());
		statement.execute();
	}

}

