package dbconnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import patient.Examination;

public class ExaminationConnection {

	private Connection conn = null;
	
	public ExaminationConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (Examination currE) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "INSERT INTO `doctormangementsystem`.`examination` (`ExaminationID`, `PatientID`, `system`, `Inspection`, `Palpation`, `Percussion`, `Ausculation`) VALUES ('";
			sql += currE.getExaminationID() + "', '"; 
			sql += currE.getPatientID() + "', '";
			sql += currE.getSystem() + "', '";
			sql += currE.getInspection() + "', '";
			sql += currE.getPalpation() + "', '";
			sql += currE.getPercussion() + "', '";
			sql += currE.getAusculation() + "')" ;
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}

	}
	
	public void update (Examination currE) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "UPDATE `doctormangementsystem`.`examination` SET `PatientID`='";
			sql += currE.getPatientID() + "', `system`='"; 
			sql += currE.getSystem() + "', `Inspection`='";
			sql += currE.getInspection() + "', `Palpation`='";
			sql += currE.getPalpation() + "', `Percussion`='";
			sql += currE.getPercussion() + "', `Ausculation`='";
			sql += currE.getAusculation() + "' WHERE `ExaminationID`='";
			sql += currE.getExaminationID() + "'";
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}
	}
	
	
	
	public void delete (Examination currE) throws SQLException, ClassNotFoundException {
		Statement stmt = null;
		try{
			
			stmt = conn.createStatement();
			String sql = null;
			
			sql = "DELETE FROM `doctormangementsystem`.`examination` WHERE `ExaminationID`='";
			sql += currE.getExaminationID() + "'" ;
			stmt.execute(sql);
		}
		finally{
			if(stmt != null)
				stmt.close();
		}
	}

}
