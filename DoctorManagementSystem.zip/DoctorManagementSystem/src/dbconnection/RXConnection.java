
package dbconnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import patient.RX;

public class RXConnection {

	private Connection conn = null;
	
	public RXConnection () throws SQLException, ClassNotFoundException {
		conn = DBSchemaConnection.getConnection();
	}
	
	public void add (RX currR) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "INSERT INTO `doctormangementsystem`.`rx` (`RXID`, `PatientID`, `Name`, `DrugForm`, `Strength`, `Quantity`, `Detail`, `DosageTime`, `Dosage`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currR.getRXID());
		statement.setString(2, currR.getPatientID());
		statement.setString(3, currR.getName());
		statement.setString(4, currR.getDrugForm());
		statement.setString(5, currR.getStrength());
		statement.setInt(6, currR.getQuantity());
		statement.setString(7, currR.getDetail());
		statement.setString(8, currR.getDosageTime());
		statement.setString(9, currR.getDosage());
		statement.execute();
	}
	
	public void update (RX currR) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "UPDATE `doctormangementsystem`.`rx` SET `PatientID`=?, `Name`=?, `DrugForm`=?, `Strength`=?, `Quantity`=?, `Detail`=?, `DosageTime`=?, `Dosage`=? WHERE `RXID`=?";

		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currR.getPatientID());
		statement.setString(2, currR.getName());
		statement.setString(3, currR.getDrugForm());
		statement.setString(4, currR.getStrength());
		statement.setInt(5, currR.getQuantity());
		statement.setString(6, currR.getDetail());
		statement.setString(7, currR.getDosageTime());
		statement.setString(8, currR.getDosage());
		statement.setString(9, currR.getRXID());
		statement.execute();
	}
	
	
	
	public void delete (RX currR) throws SQLException, ClassNotFoundException {
		String sql = null;
		sql = "DELETE FROM `doctormangementsystem`.`rx` WHERE `RXID`=?";
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, currR.getRXID());
		statement.execute();
	}

}

